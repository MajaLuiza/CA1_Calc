# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 18:39:20 2018

@author: 10392409
"""

import unittest
from calc import add, multiply, subtract, divide, exponent, squareRoot, factorial, sin, cos, tan, square

class CalculatorTest(unittest.TestCase):
    
    def testAdd(self):
        self.assertEqual(4, add(2,2))
        self.assertEqual(-10, add(5,-15))
        self.assertEqual(2.3, add(0.3,2))
        self.assertEqual(12, add(0,12))
        
    def testMultiply(self):
        self.assertEqual(4, multiply(2,2))
        self.assertEqual(10, multiply(5,2))
        self.assertEqual(5, multiply(-5,-1))
        self.assertEqual(-12, multiply(2,-6))
        self.assertEqual(0, multiply(32,0))
        self.assertEqual(9, multiply(15,0.6))
    
    def testSubtract(self):
        self.assertEqual(2, subtract(5,3))
        self.assertEqual(1, subtract(9,8))
        self.assertEqual(-30, subtract(70,100))
        self.assertEqual(3, subtract(-5,-8))
        
    def testDivide (self):
        self.assertEqual(2, divide(10,5))
        self.assertEqual(-3, divide(9,-3))
        self.assertEqual('Division by zero not allowed', divide(5,0))
        self.assertEqual(7.2, divide(90,12.5))
        self.assertEqual(0.36, divide(18,50))
        #self.assertRaises(ZeroDivisionError, divide, 5,0)
        
    def testExponent(self):
        self.assertEqual(4, exponent(2,2))
        self.assertEqual(3.872983346207417, exponent(15,0.5))
        self.assertEqual(216, exponent(6,3))
        self.assertEqual(-7776, exponent(-6,5))
        self.assertEqual(0.1111111111111111, exponent(3,-2))
    
    def testSquareRoot(self):
        self.assertEqual(4, squareRoot(16))
        self.assertEqual(5, squareRoot(25))
        self.assertEqual(4.47213595499958, squareRoot(20))
        self.assertEqual('Invalid input', squareRoot(0))
        self.assertEqual(10, squareRoot(100))
        
    def testFactorial(self):
        self.assertEqual(2, factorial(2))
        self.assertEqual(1, factorial(0))
        self.assertEqual(40320, factorial(8))
        self.assertEqual(None, factorial(-5))
    
    def testSin(self):
        self.assertEqual(-0.27941549819892586, sin(6))
        self.assertEqual(-0.9092974268256817, sin(-2))
        self.assertEqual(-0.5440211108893698, sin(10))
        self.assertEqual(0.479425538604203, sin(0.5))
        
    def testCos(self):
        self.assertEqual(-0.9576594803233847, cos(16))
        self.assertEqual(-0.32328956686350335, cos(1.9))
        self.assertEqual(-0.8578030932449878, cos(-78))
        self.assertEqual(0.022126756261955736, cos(55))
    
    def testTan(self):
        self.assertEqual(-2.185039863261519, tan(2))
        self.assertEqual(1.6197751905438615, tan(45))
        self.assertEqual(-1.3386902103511544, tan(-180))
        self.assertEqual(-1.2386276162240966, tan(2.25))
        
    def testSqrt(self):
        self.assertEqual(9, square(3))
        self.assertEqual(625, square(-25))
        self.assertEqual(0.31360000000000005, square(0.56))
        self.assertEqual(6400, square(-80))
        self.assertEqual(0, square(0))
    
    
        
unittest.main()

