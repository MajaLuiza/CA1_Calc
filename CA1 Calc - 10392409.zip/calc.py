# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 18:50:23 2018

@author: 10392409
"""
# import math - mathematical functions from python's library
import math

#caculate addition of the numbers
def add(first,second):
    return first + second
# multiplication of numbers
def multiply(first, second):
    return first*second
# calculate subtraction of numbers
def subtract(first, second):
    return first-second
#calculate division of the numbers
def divide(first, second):
    if second == 0:
        return 'Division by zero not allowed'
    return first/second
#calculate exponentiation
def exponent(first, second):
    return first**second
# calculate square root of the number
def squareRoot(first):
    if first == 0:
        return 'Invalid input'
    return first **(0.5)
#calculate factorial of the number
def factorial(first):
    if first == 0:
        return 1
    if first <0:
        return None
    else:
        return first * factorial (first - 1)
#calculate sine
def sin(first):
    return math.sin(first)
#calculate cosine
def cos(first):
    return math.cos(first)
#calculate tangent
def tan(first):
    return math.tan(first)
#calculate square
def square(first):
    return first**2


#fnction to show the option menu to the user
def CalcMenu():
    print('Welcome to Calculator')
    print('Please select the number from the below option menu')
    print('Add: 1')
    print('Subtract: 2')
    print('Multiply: 3')
    print('Divide: 4')
    print('Square: 5')
    print('Exponent: 6')
    print('Square Root: 7')
    print('Factorial: 8')
    print('Sine: 9')
    print('Cosine: 10')
    print('Tangent: 11')
    print('Exit: 12')    
  
#calling the menu function to prompt the user to select the option
CalcMenu()


while True:
    try:
        selection = int(input('Please select the operation 1-12: '))
        break
    except:
        print('Invalid Input. Please enter a numeric value')
        
while selection != 12:
# option 1 - addition
    if selection == 1:
        while 1==1:      # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                second = float(input('Please enter a second number: '))
                print('Result = ', add(first, second))
                break
            except ValueError:
                   print('Invalid Input')
#option 2 - subtraction
    elif selection == 2:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                second = float(input('Please enter a second number: '))
                print('Result = ', subtract(first, second))
                break
            except ValueError:
                print('Invalid Input')
#option 3 - multiplication
    elif selection == 3:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                second = float(input('Please enter a second number: '))
                print('Result = ', multiply(first, second))
                break
            except ValueError:
                print('Invalid Input')
#option 4 - division
    elif selection == 4:     
        while 1==1:   # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                second = float(input('Please enter a second number: '))
                print('Result = ', divide(first, second))
                break
            except ValueError:
                print('Invalid Input')
#option 5 - square
    elif selection == 5:
        while 1==1:    # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', square(first))
                break
            except ValueError:
                print('Invalid Input')
#option 6 - exponentiation
    elif selection == 6:   
        while 1==1:    # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                second = float(input('Please enter a second number: '))
                print('Result = ', exponent(first, second))
                break
            except ValueError:
                print('Invalid Input')
#option 7 - square root
    elif selection == 7:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', squareRoot(first))
                break
            except ValueError:
                print('Invalid Input')
#option 8 - factorial
    elif selection == 8:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', factorial(first))
                break
            except ValueError:
                print('Invalid Input')
#option 9 - sine
    elif selection == 9:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', math.sin(first))
                break
            except ValueError:
                print('Invalid Input')
#option 10 - cosine
    elif selection == 10:
        while 1==1:     # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', math.cos(first))
                break
            except ValueError:
                print('Invalid Input')
#option 11 - tangent
    elif selection == 11:
        while 1==1:    # user input validation - number validation
            try:
                first = float(input('Please enter a first number: '))
                print('Result = ', math.tan(first))
                break
            except ValueError:
                print('Invalid Input')
 
#calling the menu function to show the options for more calculations
    CalcMenu()
    while True:
        try:
            selection = int(input('Please select the operation 1-12: '))
            break
        except:
            print('Invalid Input. Please enter a numeric value')

            
